# SSEC-Isogeny
ZKP of identity, Unruh's construction
